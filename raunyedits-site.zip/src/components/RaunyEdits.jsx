import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sun, Moon } from "lucide-react";

export default function RaunyEdits() {
  const [darkMode, setDarkMode] = useState(true);

  const presentations = [
    {
      title: "Modern Tech Presentation",
      description: "A sleek, professional PPT for tech startups or demos.",
      image: "/ppt1.png",
      link: "https://your-link.com/ppt1"
    },
    {
      title: "Educational Science Deck",
      description: "Perfect for school/college projects on science topics.",
      image: "/ppt2.png",
      link: "https://your-link.com/ppt2"
    }
  ];

  return (
    <div className={darkMode ? "bg-black text-white min-h-screen" : "bg-white text-black min-h-screen"}>
      <div className="p-4 flex justify-between items-center">
        <h1 className="text-3xl font-bold">Raunyedits</h1>
        <Button onClick={() => setDarkMode(!darkMode)} variant="ghost">
          {darkMode ? <Sun /> : <Moon />}
        </Button>
      </div>

      <div className="p-4 text-center">
        <h2 className="text-xl md:text-2xl font-semibold">Premium PowerPoint Presentations</h2>
        <p className="text-sm text-muted-foreground max-w-xl mx-auto mt-2">
          Professionally crafted slides for education, business, and more. Instant download & ready to impress.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
        {presentations.map((ppt, index) => (
          <Card key={index} className="rounded-2xl shadow-md">
            <img src={ppt.image} alt={ppt.title} className="rounded-t-2xl w-full h-48 object-cover" />
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold">{ppt.title}</h3>
              <p className="text-sm text-muted-foreground">{ppt.description}</p>
              <a href={ppt.link} target="_blank" rel="noopener noreferrer">
                <Button className="mt-3 w-full">Buy Now</Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>

      <footer className="text-center p-4 text-sm text-muted-foreground">
        © 2025 Raunyedits. Made with ❤️
      </footer>
    </div>
  );
}